/*
 * Author: Majdi M. S. Awad
 * Client: Olena Manilich
 * Date: May 2024
 * Email: majdiawad336@gmail.com
 */

document.addEventListener('DOMContentLoaded', function() {
    let currentStep = 0;
    const formSteps = document.querySelectorAll('.form-step');
    const progressSteps = document.querySelectorAll('.progress-bar .step');

    function showStep(step) {
        formSteps.forEach((formStep, index) => {
            formStep.classList.toggle('active', index === step);
            progressSteps[index].classList.toggle('active', index <= step);
        });
    }

    window.nextStep = function() {
        if (currentStep < formSteps.length - 1) {
            currentStep++;
            showStep(currentStep);
        }
    };

    showStep(currentStep);

    window.loadSubcategories = function() {
        const categoryName = document.getElementById('case_category_name').value;
        fetch(`../system/cases/get_subcategories.php?category=${categoryName}`)
            .then(response => response.json())
            .then(data => {
                const subcategorySelect = document.getElementById('case_subcategory_name');
                subcategorySelect.innerHTML = '<option value="" disabled selected>Select a subcategory</option>'; 
                data.forEach(subcategory => {
                    const option = document.createElement('option');
                    option.value = subcategory.id;  
                    option.textContent = subcategory.name;
                    subcategorySelect.appendChild(option);
                });
            });
    };

    fetch('../system/cases/get_categories.php')
        .then(response => response.json())
        .then(data => {
            const categorySelect = document.getElementById('case_category_name');
            categorySelect.innerHTML = '<option value="" disabled selected>Select a category</option>'; 
            data.forEach(category => {
                const option = document.createElement('option');
                option.value = category.id;
                option.textContent = category.name;
                categorySelect.appendChild(option);
            });
            loadSubcategories(); 
        });

    fetch('../system/cases/get_types.php')
        .then(response => response.json())
        .then(data => {
            const typeSelect = document.getElementById('case_type_name');
            typeSelect.innerHTML = '<option value="" disabled selected>Select a type</option>'; 
            data.forEach(type => {
                const option = document.createElement('option');
                option.value = type.id;  
                option.textContent = type.name;
                typeSelect.appendChild(option);
            });
        });
		
    fetch('../system/cases/get_clients.php')
        .then(response => response.json())
        .then(data => {
            const clientSelect = document.getElementById('client_id');
            clientSelect.innerHTML = '<option value="" disabled selected>Select a Client</option>'; 
            data.forEach(client => {
                const option = document.createElement('option');
                option.value = client.id;  // Ensure this is the correct ID
                option.textContent = client.name;
                clientSelect.appendChild(option);
            });
        });

    document.getElementById('multiStepForm').addEventListener('submit', function(event) {
        const subcategory = document.getElementById('case_subcategory_name').value;
        const type = document.getElementById('case_type_name').value;
        
        if (subcategory === "" || subcategory === "undefined") {
            alert("Please select a valid subcategory.");
            event.preventDefault();
        }
        
        if (type === "" || type === "undefined") {
            alert("Please select a valid case type.");
            event.preventDefault();
        }
    });
});
