// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com
<?php
require '../system/payments_total.php';
?>

document.addEventListener('DOMContentLoaded', function () {
    console.log("DOM fully loaded and parsed");

    const ctx = document.getElementById('pieChart').getContext('2d');

    if (ctx) {
        console.log("Canvas context obtained");

        const totalIncomes = <?php $totalAmount ?>;
        const totalExpenses = 30000;

        const data = {
            labels: ['Total Incomes', 'Total Expenses'],
            datasets: [{
                data: [totalIncomes, totalExpenses],
                backgroundColor: ['#36a2eb', '#ff6384']
            }]
        };

        new Chart(ctx, {
            type: 'pie',
            data: data
        });

        console.log("Chart created");
    } else {
        console.error("Failed to obtain canvas context");
    }
});
