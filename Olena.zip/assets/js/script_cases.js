/* 
// Author: Majdi M. S. Awad
// Client: Olena Manilich
// Date: May 2024
// Email: majdiawad336@gmail.com
*/
let offset = 0;
const limit = 10;

function searchCases() {
    offset = 0;
    const formData = new FormData(document.getElementById('searchForm'));
    fetchCases(formData);
}

function loadMore() {
    offset += limit;
    const formData = new FormData(document.getElementById('searchForm'));
    formData.append('offset', offset);
    fetchCases(formData, true);
}

function fetchCases(formData, append = false) {
    formData.append('limit', limit);
    fetch('../system/cases/search_cases.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const tableBody = document.querySelector('#casesTable tbody');
        if (!append) tableBody.innerHTML = '';
        data.forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>CN.${row.id}</td>
                <td>${row.category_name}</td>
                <td>${row.subcategory_name}</td>
                <td>${row.type_name}</td>
                <td>${row.court_name}</td>
                <td>${row.court_type}</td>
                <td>${row.client_name}</td>
                <td><a href="edit_case.php?id=${row.id}">View</a></td>
                <td><a href="#" onclick="deleteCase(${row.id})">Delete</a></td>
            `;
            tableBody.appendChild(tr);
        });
    })
    .catch(error => console.error('Error:', error));
}

function deleteCase(id) {
    if (confirm('Are you sure you want to delete this case?')) {
        const formData = new FormData();
        formData.append('id', id);
        fetch('../system/cases/delete_case.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Case deleted successfully');
                searchCases(); // Refresh the table
            } else {
                alert('Error deleting case: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }
}

// Initial load
document.addEventListener('DOMContentLoaded', () => {
    loadMore();
});
