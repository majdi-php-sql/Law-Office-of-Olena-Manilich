<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

// Database connection parameters
$host = 'localhost';
$dbname = 'olena';
$user = 'root';
$password = 'Majdi@00800';

try {
    // Set the PDO error mode to exception and create a new PDO instance
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    $pdo = new PDO($dsn, $user, $password, $options);

} catch (PDOException $e) {
    // Catch any errors and display a generic message
    // Log the detailed error message for debugging
    error_log("Database connection error: " . $e->getMessage());
    echo "Database connection failed.";
}
?>
