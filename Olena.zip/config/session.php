<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

session_start();

if (!isset($_SESSION['user_id'])) {
    echo "You are not logged in.";
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$role = $_SESSION['role'];

?>