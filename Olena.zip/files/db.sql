-- Create tables for Case Categories and Subcategories
CREATE TABLE case_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

INSERT INTO case_categories (name) VALUES ('Immigration'), ('Personal Injury');

CREATE TABLE case_subcategories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    FOREIGN KEY (category_id) REFERENCES case_categories(id) ON DELETE CASCADE
);

INSERT INTO case_subcategories (category_id, name) VALUES 
(1, 'Marriage Visa'), (1, 'Green Card'), (1, 'Citizenship'), (1, 'Investor Visa'),
(2, 'Auto Accident'), (2, 'Medical Negligence'), (2, 'Slip and Fall');

-- Create table for Case Types
CREATE TABLE case_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

INSERT INTO case_types (name) VALUES ('K1 Visa'), ('Re-entry Permit'), ('Naturalization'), ('E2 Visa'), ('EB5 Visa'), ('Car Accident'), ('Medical Negligence'), ('Wrongful Death');

-- Create table for Clients
CREATE TABLE clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(255)
);

INSERT INTO clients (name, address, phone, email) VALUES 
('John Doe', '123 Elm St, New York, NY', '555-1234', 'john.doe@example.com'), 
('Jane Smith', '456 Oak St, New York, NY', '555-5678', 'jane.smith@example.com');

-- Create table for Cases
CREATE TABLE cases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    subcategory_id INT NOT NULL,
    type_id INT NOT NULL,
    court_name VARCHAR(255),
    court_type VARCHAR(255),
    client_id INT NOT NULL,
    short_description TEXT,
    full_description TEXT,
    case_fees DECIMAL(10, 2) DEFAULT 0,
    FOREIGN KEY (category_id) REFERENCES case_categories(id),
    FOREIGN KEY (subcategory_id) REFERENCES case_subcategories(id),
    FOREIGN KEY (type_id) REFERENCES case_types(id),
    FOREIGN KEY (client_id) REFERENCES clients(id)
);

INSERT INTO cases (category_id, subcategory_id, type_id, court_name, court_type, client_id, short_description, full_description, case_fees) VALUES 
(1, 1, 1, 'NY District Court', 'Federal', 1, 'Marriage Visa Case', 'Full description of Marriage Visa case', 2000.00), 
(2, 6, 6, 'NY State Court', 'State', 2, 'Car Accident Case', 'Full description of Car Accident case', 5000.00);

-- Create table for Case Files
CREATE TABLE case_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

INSERT INTO case_files (case_id, file_path) VALUES 
(1, 'files/marriage_visa_document.pdf'), 
(2, 'files/car_accident_photos.zip');

-- Create table for Requests
CREATE TABLE requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    status ENUM('approved', 'rejected', 'modification_request') DEFAULT 'modification_request',
    comment TEXT,
    FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

INSERT INTO requests (case_id, status, comment) VALUES 
(1, 'approved', 'Request for additional documents approved'), 
(2, 'modification_request', 'Request for more accident details');

-- Create table for Court Dates
CREATE TABLE court_dates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    court_date DATETIME NOT NULL,
    FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

INSERT INTO court_dates (case_id, court_date) VALUES 
(1, '2023-07-15 10:00:00'), 
(2, '2023-08-20 14:00:00');

-- Create table for Judgements
CREATE TABLE judgements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

INSERT INTO judgements (case_id, file_path) VALUES 
(1, 'files/marriage_visa_judgement.pdf'), 
(2, 'files/car_accident_judgement.pdf');

-- Create table for Payment Methods
CREATE TABLE payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    method_name VARCHAR(255) NOT NULL
);

INSERT INTO payment_methods (method_name) VALUES ('Credit Card'), ('Bank Transfer'), ('Cash');

-- Create table for Payments
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    payment_method_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_date DATETIME NOT NULL,
    FOREIGN KEY (case_id) REFERENCES cases(id),
    FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id)
);

INSERT INTO payments (case_id, payment_method_id, amount, payment_date) VALUES 
(1, 1, 1000.00, '2023-06-10 12:00:00'), 
(2, 2, 2500.00, '2023-06-15 15:30:00');

-- Create table for Payment Reasons
CREATE TABLE payment_reasons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reason_name VARCHAR(255) NOT NULL
);

INSERT INTO payment_reasons (reason_name) VALUES ('Consultation Fee'), ('Court Fee'), ('Miscellaneous');

-- Create table for Expenses
CREATE TABLE expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method_id INT NOT NULL,
    reason_id INT NOT NULL,
    comment TEXT,
    expense_date DATETIME NOT NULL,
    FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id),
    FOREIGN KEY (reason_id) REFERENCES payment_reasons(id)
);

INSERT INTO expenses (amount, payment_method_id, reason_id, comment, expense_date) VALUES 
(300.00, 3, 1, 'Consultation fee payment', '2023-06-05 10:00:00'), 
(150.00, 1, 2, 'Court filing fee', '2023-06-12 11:00:00');

-- Create table for Employees
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    age INT,
    mobile VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    joining_date DATE,
    position VARCHAR(255)
);

INSERT INTO employees (name, age, mobile, email, address, joining_date, position) VALUES 
('Alice Johnson', 35, '555-2345', 'alice.johnson@example.com', '789 Pine St, New York, NY', '2020-01-15', 'Lawyer'), 
('Bob Williams', 40, '555-6789', 'bob.williams@example.com', '321 Maple St, New York, NY', '2018-03-20', 'Finance Manager');

-- Create table for Vacation Types
CREATE TABLE vacation_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(255) NOT NULL
);

INSERT INTO vacation_types (type_name) VALUES ('Annual Leave'), ('Sick Leave'), ('Maternity Leave');

-- Create table for Vacations
CREATE TABLE vacations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(id),
    FOREIGN KEY (type_id) REFERENCES vacation_types(id)
);

INSERT INTO vacations (employee_id, type_id, start_date, end_date) VALUES 
(1, 1, '2023-07-01', '2023-07-10'), 
(2, 2, '2023-07-05', '2023-07-08');

-- Create table for Announcements
CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    message TEXT NOT NULL,
    send_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

INSERT INTO announcements (employee_id, message) VALUES 
(1, 'Office will be closed on July 4th for Independence Day'), 
(2, 'Reminder: Submit expense reports by end of month');

-- Create table for Payroll
CREATE TABLE payroll (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    payment_date DATE NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

INSERT INTO payroll (employee_id, salary, payment_date) VALUES 
(1, 5000.00, '2023-06-30'), 
(2, 6000.00, '2023-06-30');

-- Create table for Users with hashed passwords using MD5
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password CHAR(32) NOT NULL,
    role ENUM('Super Admin', 'Lawyer', 'Finance', 'HR') NOT NULL
);

INSERT INTO users (username, password, role) VALUES 
('admin', MD5('admin123'), 'Super Admin'), 
('alice', MD5('password1'), 'Lawyer'), 
('bob', MD5('password2'), 'Finance');

-- Create table for System Settings (generic settings table)
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(255) NOT NULL,
    setting_value TEXT
);

INSERT INTO system_settings (setting_key, setting_value) VALUES 
('office_name', 'Law Office of Olena Manilich'), 
('office_address', '123 Elm St, New York, NY');
