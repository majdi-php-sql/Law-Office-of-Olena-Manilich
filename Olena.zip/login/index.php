<?php
$error_message = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : '';
?>
<!DOCTYPE html>
<html><!-- This page was made by Majdi M. S. Awad -->
<head>
    <meta charset="utf-8">
    <title>U.S. Immigration Lawyer - Olena Manilich</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="wrapper" style="background-image: url('images/bg-login-form-1.jpg');">
        <div class="inner">
            <div class="image-holder">
                <img src="images/login-form-1.jpg" alt="">
            </div>
            <form action="login.php" method="post">
                <h3>Olena Manilich</h3>
                <p style="text-align: justify;">
                    This is the system of the Law Office of Olena Manilich. If you have the login information, please enter it or ask your IT department to help you.
                </p>
                <br>
                <?php if ($error_message): ?>
                    <div class="error-message">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                <div class="form-wrapper">
                    <input type="text" name="username" placeholder="Username" class="form-control" required>
                    <i class="zmdi zmdi-account"></i>
                </div>
                <div class="form-wrapper">
                    <input type="password" name="password" placeholder="Password" class="form-control" required>
                    <i class="zmdi zmdi-lock"></i>
                </div>
                <button type="submit">Login
                    <i class="zmdi zmdi-arrow-right"></i>
                </button>
            </form>
        </div>
    </div>
</body><!-- This page was made by Majdi M. S. Awad -->
</html>
