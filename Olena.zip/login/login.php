<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

session_start();
require '../config/db_connect.php'; // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password using MD5
    $hashed_password = md5($password);

    try {
        // Prepare the SQL statement to prevent SQL injection
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
        $stmt->execute(['username' => $username, 'password' => $hashed_password]);

        $user = $stmt->fetch();

        if ($user) {
            // Store user data in the session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Redirect based on user role
            switch ($user['role']) {
                case 'Super Admin':
                    header("Location: ../superadmin/dashboard.php");
                    break;
                case 'Lawyer':
                    header("Location: lawyer_dashboard.php");
                    break;
                case 'Finance':
                    header("Location: finance_dashboard.php");
                    break;
                case 'HR':
                    header("Location: hr_dashboard.php");
                    break;
                default:
                    echo "Invalid role.";
                    session_destroy();
                    break;
            }
            exit();
        } else {
            // Redirect to index.php with an error message
            header("Location: index.php?error=Invalid username or password.");
            exit();
        }
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        header("Location: index.php?error=An error occurred. Please try again later.");
        exit();
    }
}
?>
