<?php
require '../config/session.php';
require '../config/db_connect.php';
require '../system/cases/cases_page.php';
require '../system/summary_about_cases.php';

?>
<!doctype html>
<!-- This page was made by Majdi M. S. Awad -->
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich</title>
    <meta name="description" content="Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../vendors/jqvmap/dist/jqvmap.min.css">
	<link rel="stylesheet" href="../assets/css/style_cases.css">



    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="dashboard.php">Olena Manilich</a>
                <a class="navbar-brand hidden" href="dashboard.php">Olena Manilich</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Cases</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases.php"> <i class="menu-icon fa fa-book"></i>Cases </a>
                    </li>
                    <h3 class="menu-title">Finance</h3><!-- /.menu-title -->

                    <li>
                        <a href="payments.php"> <i class="menu-icon fa fa-money"></i>Payments </a>
                    </li>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-dollar"></i>Expenses </a>
                    </li>
                    <h3 class="menu-title">Human Resorce</h3><!-- /.menu-title -->
                    <li>
                        <a href="employees.php"> <i class="menu-icon fa fa-users"></i>List of Employees </a>
                    </li>
					<li>
                        <a href="vacations.php"> <i class="menu-icon fa fa-plane"></i>Vacations </a>
                    </li>
					<li>
                        <a href="announcement.php"> <i class="menu-icon fa fa-volume-up"></i>Announcement </a>
                    </li>
					<li>
                        <a href="payroll.php"> <i class="menu-icon fa fa-credit-card"></i>Payroll </a>
                    </li>
					<h3 class="menu-title">Reports</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Cases Reports </a>
                    </li>
					<li>
                        <a href="Payments_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Payments Reposts </a>
                    </li>
					<li>
                        <a href="expenses_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Expenses Reports </a>
                    </li>
										<h3 class="menu-title">Marketing</h3><!-- /.menu-title -->
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question"></i>Queries </a>
                    </li>
					<li>
                        <a href="meeting.php"> <i class="menu-icon fa fa-calendar"></i>Meetings </a>
                    </li>
					<h3 class="menu-title">Administration</h3><!-- /.menu-title -->
                    <li>
                        <a href="users.php"> <i class="menu-icon fa fa-user"></i>users </a>
                    </li>
					<li>
                        <a href="system.php"> <i class="menu-icon fa fa-cogs"></i>system </a>
                    </li>
					<li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4>Welcome to your dashboard <?= htmlspecialchars($username) ?></h4>
                        </div>
				</header><!-- /header -->
        <!-- Header-->
        <div class="content mt-3">

            <div class="col-sm-12">
			<!-- start box no.1 -->
			                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-secondary">
                                <strong class="card-title text-light">Total Fees</strong>
                            </div>
                            <div class="card-body text-white bg-primary">
                                <p class="card-text text-light">Total fees for all cases:$<?php echo number_format($totalCaseFees, 2); ?>.</p>
                            </div>
                        </div>
                    </div>
			<!-- end box no.1 -->
			<!-- start box no.2 -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header bg-dark">
                                <strong class="card-title text-light">Total Cases</strong>
                            </div>
                            <div class="card-body text-white bg-danger">
                                <p class="card-text text-light">Total Number of Cases: <?php echo $totalCases; ?> cases </p>
                            </div>
                        </div>
                    </div>
			<!-- end box no.2 -->	
			<!-- Start Paragraph -->
				<p style="align: justify;"> Here you can search for the cases the office is working on and modify their data, and you can also add new cases. If there is any technical problem, you can contact the Information Technology Department.</p>
			<!-- End Paragraph -->
			<!-- Start Add -->
			<div>
			    <button class="btn-add" onclick="location.href='add_case.php'">Add New Case</button>
			</div>
			<!-- End Add -->
			<!-- Start search form and cases table -->
			    <form id="searchForm">
        <div class="form-group col-md-3">
            <input type="number" id="id" name="id" placeholder="Search By Case Number">
        </div>
        <div class="form-group col-md-3">
            <select class="field" id="category_id" name="category_id">
                <option value="">Select Category</option>
                <?php foreach ($categoryOptions as $option): ?>
                    <option value="<?= $option['id'] ?>"><?= $option['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select class="field" id="subcategory_id" name="subcategory_id">
                <option value="">Select Subcategory</option>
                <?php foreach ($subcategoryOptions as $option): ?>
                    <option value="<?= $option['id'] ?>"><?= $option['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select class="field" id="type_id" name="type_id">
                <option value="">Select Type</option>
                <?php foreach ($typeOptions as $option): ?>
                    <option value="<?= $option['id'] ?>"><?= $option['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select class="field" id="client_id" name="client_id">
                <option value="">Select Client</option>
                <?php foreach ($clientOptions as $option): ?>
                    <option value="<?= $option['id'] ?>"><?= $option['name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select class="field" id="court_name" name="court_name">
                <option value="">Select Court Name</option>
                <?php foreach ($courtNameOptions as $option): ?>
                    <option value="<?= $option['court_name'] ?>"><?= $option['court_name'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-3">
            <select class="field" id="court_type" name="court_type">
                <option value="">Select Court Type</option>
                <?php foreach ($courtTypeOptions as $option): ?>
                    <option value="<?= $option['court_type'] ?>"><?= $option['court_type'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button class="btn-cases" type="button" onclick="searchCases()">Search</button>
    </form>

    <table id="casesTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Category</th>
                <th>Subcategory</th>
                <th>Type</th>
                <th>Court Name</th>
                <th>Court Type</th>
                <th>Client</th>
				<th>View</th>
				<th>Delete</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
    <button class="btn-loadmore" id="loadMore" onclick="loadMore()">Load More</button>


			<!-- End search form and cases table -->

			</div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
    <script src="../assets/js/script_cases.js"></script>
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>


    <script src="../vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="../assets/js/dashboard.js"></script>
    <script src="../assets/js/widgets.js"></script>
    <script src="../vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
</body>

</html>
