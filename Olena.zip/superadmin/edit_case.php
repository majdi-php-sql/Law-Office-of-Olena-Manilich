<?php
require '../config/session.php';
require '../config/db_connect.php';
require '../system/cases/cases_page.php';
require '../system/cases/edit_cases.php';
require '../system/summary_about_cases.php';

?>
<!doctype html>
<!-- This page was made by Majdi M. S. Awad -->
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich</title>
    <meta name="description" content="Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="../assets/css/style_cases.css">
    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- Modal CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
</head>

<body>

    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="dashboard.php">Olena Manilich</a>
                <a class="navbar-brand hidden" href="dashboard.php">Olena Manilich</a>
            </div>
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Cases</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases.php"> <i class="menu-icon fa fa-book"></i>Cases </a>
                    </li>
                    <h3 class="menu-title">Finance</h3><!-- /.menu-title -->
                    <li>
                        <a href="payments.php"> <i class="menu-icon fa fa-money"></i>Payments </a>
                    </li>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-dollar"></i>Expenses </a>
                    </li>
                    <h3 class="menu-title">Human Resource</h3><!-- /.menu-title -->
                    <li>
                        <a href="employees.php"> <i class="menu-icon fa fa-users"></i>List of Employees </a>
                    </li>
                    <li>
                        <a href="vacations.php"> <i class="menu-icon fa fa-plane"></i>Vacations </a>
                    </li>
                    <li>
                        <a href="announcement.php"> <i class="menu-icon fa fa-volume-up"></i>Announcement </a>
                    </li>
                    <li>
                        <a href="payroll.php"> <i class="menu-icon fa fa-credit-card"></i>Payroll </a>
                    </li>
                    <h3 class="menu-title">Reports</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Cases Reports </a>
                    </li>
                    <li>
                        <a href="Payments_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Payments Reports </a>
                    </li>
                    <li>
                        <a href="expenses_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Expenses Reports </a>
                    </li>
                    <h3 class="menu-title">Marketing</h3><!-- /.menu-title -->
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question"></i>Queries </a>
                    </li>
                    <li>
                        <a href="meeting.php"> <i class="menu-icon fa fa-calendar"></i>Meetings </a>
                    </li>
                    <h3 class="menu-title">Administration</h3><!-- /.menu-title -->
                    <li>
                        <a href="users.php"> <i class="menu-icon fa fa-user"></i>Users </a>
                    </li>
                    <li>
                        <a href="system.php"> <i class="menu-icon fa fa-cogs"></i>System </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">
            <div class="header-menu">
                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4>Welcome to your dashboard <?= htmlspecialchars($username) ?></h4>
                    </div>
        </header><!-- /header -->
        <!-- Header-->
        <div class="content mt-3">
            <div class="col-sm-12">
                <!-- Start Case Information -->
                <div class="col-md-4">
                    <aside class="profile-nav alt">
                        <section class="card">
                            <div class="card-header user-header alt bg-dark">
                                <div class="media">
                                    <div class="media-body">
                                        <h2 class="text-light display-6"><?php echo $case['client_name']; ?></h2>
                                        <p><?php echo $case['category_name']; ?></p>
                                    </div>
                                </div>
                            </div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <i class="fa fa-check-circle"></i> <b>Case Fees:</b> <?php echo "$" . $case['case_fees']; ?>
                                </li>
                                <li class="list-group-item">
                                    <i class="fa fa-check-circle"></i> <b>Subcategory:</b> <?php echo $case['subcategory_name']; ?>
                                </li>
                                <li class="list-group-item">
                                    <i class="fa fa-check-circle"></i> <b>Type:</b> <?php echo $case['type_name']; ?>
                                </li>
                                <li class="list-group-item">
                                    <i class="fa fa-check-circle"></i> <b>Court:</b> <?php echo $case['court_name']; ?>
                                </li>
                            </ul>
                        </section>
                    </aside>
                </div>
                <!-- End Case Information -->

                <!-- Start Case Description -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-secondary">
                            <strong class="card-title text-light">Case Short Description</strong>
                        </div>
                        <div class="card-body text-white bg-primary">
                            <p class="card-text text-light"><?php echo $case['short_description']; ?></p>
                        </div>
                    </div>
                </div>
                <!-- End Case Description -->

                <!-- Start Court meetings -->
                <div class="col-md-4">
                    <div class="card border border-primary">
                        <div class="card-header">
                            <strong class="card-title">Hearings | <a href="#" data-toggle="modal" data-target="#addHearingModal">Add New</a></strong>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <!-- PHP Code to get Data from the table -->
                                <?php
                                // Author: Majdi M. S. Awad
                                // Client: Olena Manilich
                                // Date: May 2024
                                // Email: majdiawad336@gmail.com

                                $cid = $_GET['id'];

                                $query = "
                                    SELECT 
                                        court_dates.court_date
                                    FROM 
                                        court_dates
                                    INNER JOIN 
                                        cases ON court_dates.case_id = cases.id
                                    WHERE
                                        cases.id = :cid
                                ";

                                $stmt = $pdo->prepare($query);
                                $stmt->bindParam(':cid', $cid, PDO::PARAM_INT);
                                $stmt->execute();

                                if ($stmt->rowCount() > 0) {
                                    $court_dates = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                    foreach ($court_dates as $court_date) {
                                        echo htmlspecialchars($court_date['court_date']);
                                        echo "<hr>";
                                    }
                                } else {
                                    echo "No court dates found.";
                                }

                                $pdo = null;
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- End Court meetings -->

                <!-- Start Case Files -->
                <div class="col-md-4">
                    <div class="card border border-primary">
                        <div class="card-header">
                            <strong class="card-title">Case Files</strong>
                        </div>
                        <div class="card-body">
                            <p class="card-text">
                                <?php
                                // Author: Majdi M. S. Awad
                                // Client: Olena Manilich
                                // Date: May 2024
                                // Email: majdiawad336@gmail.com
                                if (isset($_GET['id']) && !empty($_GET['id'])) {
                                    $cf_id = $_GET['id'];
                                    require '../config/db_connect.php';
                                    if ($pdo) {
                                        try {
                                            $sql = "SELECT * FROM case_files WHERE case_id = ?";
                                            $stmt = $pdo->prepare($sql);
                                            $stmt->execute([$cf_id]);
                                            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                            if ($results) {
                                                foreach ($results as $result) {
                                                    $file_path = $result['file_path'];
                                                    $upload_date = $result['upload_date'];

                                                    echo '<a href="' . htmlspecialchars($file_path) . '">' . htmlspecialchars($file_path) . '</a><br>';
                                                    echo "Upload Date: " . htmlspecialchars($upload_date) . "<br>";
                                                    echo "<hr>";
                                                }
                                            } else {
                                                echo "No case files found with the provided case ID.";
                                            }
                                        } catch (PDOException $e) {
                                            echo "Database error: " . htmlspecialchars($e->getMessage());
                                        }
                                        $stmt = null;
                                        $pdo = null;
                                    } else {
                                        echo "Failed to connect to the database.";
                                    }
                                } else {
                                    echo "No case ID provided.";
                                }
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- End Case Files -->

                <!-- Start Case Full Description -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-secondary">
                            <strong class="card-title text-light">Case Full Description</strong>
                        </div>
                        <div class="card-body text-white bg-primary">
                            <p class="card-text text-light"><?php echo $case['full_description']; ?></p>
                        </div>
                    </div>
                </div>
                <!-- End Case Full Description -->

                <div class="col-md-1">
                    <div class="card">
                        <a href="edit_this_case.php?id=<?php echo $cid; ?>"><button type="button" class="btn btn-warning">Modify</button></a>
                    </div>
                </div>
            </div> <!-- .content -->
        </div><!-- /#right-panel -->

        <!-- Right Panel -->

        <!-- Modal Structure -->
        <div class="modal fade" id="addHearingModal" tabindex="-1" role="dialog" aria-labelledby="addHearingModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="../system/cases/hearing.php" method="post">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addHearingModalLabel">Add New Hearing</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="case_id" value="<?php echo htmlspecialchars($cid); ?>">
                            <div class="form-group">
                                <label for="court_date">Court Date & Time</label>
                                <input type="datetime-local" class="form-control" id="court_date" name="court_date" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script src="../assets/js/script_cases.js"></script>
        <script src="../vendors/jquery/dist/jquery.min.js"></script>
        <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
        <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="../assets/js/main.js"></script>
        <script src="../vendors/chart.js/dist/Chart.bundle.min.js"></script>
        <script src="../assets/js/dashboard.js"></script>
        <script src="../assets/js/widgets.js"></script>
        <script src="../vendors/jqvmap/dist/jquery.vmap.min.js"></script>
        <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
        <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>

    </body>
</html>
