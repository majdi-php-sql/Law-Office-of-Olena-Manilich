<?php
require '../config/session.php';
require '../config/db_connect.php';
require '../system/cases/cases_page.php';
require '../system/cases/edit_cases.php';
require '../system/cases/get_files.php';
require '../system/summary_about_cases.php';

?>
<!doctype html>
<!-- This page was made by Majdi M. S. Awad -->
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich</title>
    <meta name="description" content="Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../vendors/jqvmap/dist/jqvmap.min.css">
	<link rel="stylesheet" href="../assets/css/styles_add_cases.css">
	<script src="../assets/js/case_edit_script.js" defer></script>




    <link rel="stylesheet" href="../assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="dashboard.php">Olena Manilich</a>
                <a class="navbar-brand hidden" href="dashboard.php">Olena Manilich</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Cases</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases.php"> <i class="menu-icon fa fa-book"></i>Cases </a>
                    </li>
                    <h3 class="menu-title">Finance</h3><!-- /.menu-title -->

                    <li>
                        <a href="payments.php"> <i class="menu-icon fa fa-money"></i>Payments </a>
                    </li>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-dollar"></i>Expenses </a>
                    </li>
                    <h3 class="menu-title">Human Resorce</h3><!-- /.menu-title -->
                    <li>
                        <a href="employees.php"> <i class="menu-icon fa fa-users"></i>List of Employees </a>
                    </li>
					<li>
                        <a href="vacations.php"> <i class="menu-icon fa fa-plane"></i>Vacations </a>
                    </li>
					<li>
                        <a href="announcement.php"> <i class="menu-icon fa fa-volume-up"></i>Announcement </a>
                    </li>
					<li>
                        <a href="payroll.php"> <i class="menu-icon fa fa-credit-card"></i>Payroll </a>
                    </li>
					<h3 class="menu-title">Reports</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Cases Reports </a>
                    </li>
					<li>
                        <a href="Payments_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Payments Reposts </a>
                    </li>
					<li>
                        <a href="expenses_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Expenses Reports </a>
                    </li>
										<h3 class="menu-title">Marketing</h3><!-- /.menu-title -->
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question"></i>Queries </a>
                    </li>
					<li>
                        <a href="meeting.php"> <i class="menu-icon fa fa-calendar"></i>Meetings </a>
                    </li>
					<h3 class="menu-title">Administration</h3><!-- /.menu-title -->
                    <li>
                        <a href="users.php"> <i class="menu-icon fa fa-user"></i>users </a>
                    </li>
					<li>
                        <a href="system.php"> <i class="menu-icon fa fa-cogs"></i>system </a>
                    </li>
					<li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4>Welcome to your dashboard <?= htmlspecialchars($username) ?></h4>
                        </div>
				</header><!-- /header -->
        <!-- Header-->
        <div class="content mt-3">

            <div class="col-sm-12">
				    <div class="container">
        <h1>Edit This Case</h1>
        <div class="progress-bar">
            <div class="step">Step 1</div> 
			<div class="step">Step 2</div>
            <div class="step">Step 3</div>
            <div class="step">Step 4</div>
        </div>
        <form id="multiStepForm" action="../system/cases/case_edit_data.php" method="post" enctype="multipart/form-data">
            <!-- Step 1: Case Category -->
            <div class="form-step" id="step1">
				<input name="id" value="<?php echo $c_id; ?>">
                <label for="case_category_name">Case Category</label>
                <select id="case_category_name" name="case_category_name" onchange="loadSubcategories()">
					<option value="<?php echo $case['category_id']; ?>"> <?php echo $case['category_name']; ?> </option>
					<!-- Options will be populated via JavaScript -->
                </select>
                
                <label for="case_subcategory_name">Case Subcategory</label>
                <select id="case_subcategory_name" name="case_subcategory_name">
					<option value="<?php echo $case['subcategory_id']; ?>"> <?php echo $case['subcategory_name']; ?> </option>
                    <!-- Options will be populated via JavaScript -->
                </select>

                <label for="case_type_name">Case Type</label>
                <select id="case_type_name" name="case_type_name">
					<option value="<?php echo $case['type_id']; ?>"> <?php echo $case['type_name']; ?> </option>
                    <!-- Options will be populated via PHP -->
                </select>
                <button class="btn-n" type="button" onclick="nextStep()">Next</button>
            </div>
            <!-- Step 2: Court Information -->
            <div class="form-step" id="step2">
                <label for="case_court_name">Court Name</label>
                <select id="case_court_name" name="case_court_name">
					<option value="<?php echo $case['court_name']; ?>"> <?php echo $case['court_name']; ?> </option>
                    <option value="The Court of Appeals">The Court of Appeals</option>
                    <option value="Appellate Divisions">Appellate Divisions</option>
                    <option value="The Eighth Judicial District">The Eighth Judicial District</option>
                    <option value="Supreme Court">Supreme Court</option>
                    <option value="County Court">County Court</option>
                    <option value="Court of Claims">Court of Claims</option>
                    <option value="Family Court">Family Court</option>
                    <option value="Surrogate’s Court">Surrogate’s Court</option>
                    <option value="City Court">City Court</option>
                    <option value="Town & Village Courts">Town & Village Courts</option>
                    <option value="Specialized Courts & Justice Initiatives">Specialized Courts & Justice Initiatives</option>
                </select>
                
                <label for="case_court_type">Court Type</label>
                <select id="case_court_type" name="case_court_type">
					<option value="<?php echo $case['court_type']; ?>"> <?php echo $case['court_type']; ?> </option>
                    <option value="Federal">Federal</option>
                    <option value="State">State</option>
                </select>
                <button class="btn-n" type="button" onclick="nextStep()">Next</button>
            </div>
            <!-- Step 3: Case Information & Fees -->
            <div class="form-step" id="step3">
				<label for="client_id">Client Name</label>
                <select id="client_id" name="client_id">
					<option value="<?php echo $case['client_id']; ?>"> <?php echo $case['client_name']; ?> </option>
                    <!-- Options will be populated via PHP -->
                </select>
                <label for="case_short_description">Short Description</label>
                <textarea id="case_short_description" name="case_short_description"><?php echo $case['short_description']; ?></textarea>


                <label for="case_full_description">Full Description</label>
                <textarea id="case_full_description" name="case_full_description"><?php echo $case['full_description']; ?></textarea>


                <label for="case_fees">Case Fees ($)</label>
                <input value="<?php echo $case['case_fees']; ?>" type="text" id="case_fees" name="case_fees">
                <button class="btn-n" type="button" onclick="nextStep()">Next</button>
            </div>
            <!-- Step 4: Case File & Documents -->
            <div class="form-step" id="step4">
                <label for="case_files">Add New Files</label>
                <input type="file" id="case_files" name="case_files[]" multiple>
				<div>Current Files:</div>
				<div><?php echo $file_path; ?></div>
                <button class="btn-n" type="submit">Update</button>
            </div>
        </form>
    </div>

			</div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
    <script src="../assets/js/script_cases.js"></script>
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../assets/js/main.js"></script>


    <script src="../vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="../assets/js/dashboard.js"></script>
    <script src="../assets/js/widgets.js"></script>
    <script src="../vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
</body>

</html>

