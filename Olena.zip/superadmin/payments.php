<?php
require '../config/session.php';
require '../config/db_connect.php';

// Fetch payment data
$totalAmountsQuery = $pdo->prepare("SELECT DATE(payment_date) as payment_date, SUM(amount) as total_amount FROM payments GROUP BY DATE(payment_date)");
$totalAmountsQuery->execute();
$totalAmounts = $totalAmountsQuery->fetchAll(PDO::FETCH_ASSOC);

// Fetch cases and payment methods for the form
$casesQuery = $pdo->prepare("SELECT id FROM cases");
$casesQuery->execute();
$cases = $casesQuery->fetchAll(PDO::FETCH_ASSOC);

$paymentMethodsQuery = $pdo->prepare("SELECT id, method_name FROM payment_methods");
$paymentMethodsQuery->execute();
$paymentMethods = $paymentMethodsQuery->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich</title>
    <meta name="description" content="Superadmin Dashboard | U.S. Immigration Lawyer - Olena Manilich">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .total-amounts p {
            margin: 5px 0;
        }
        .search-form {
            margin-top: 20px;
        }
        .search-results {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>

    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="dashboard.php">Olena Manilich</a>
                <a class="navbar-brand hidden" href="dashboard.php">Olena Manilich</a>
            </div>
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title">Cases</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases.php"> <i class="menu-icon fa fa-book"></i>Cases </a>
                    </li>
                    <h3 class="menu-title">Finance</h3><!-- /.menu-title -->
                    <li>
                        <a href="payments.php"> <i class="menu-icon fa fa-money"></i>Payments </a>
                    </li>
                    <li>
                        <a href="expenses.php"> <i class="menu-icon fa fa-dollar"></i>Expenses </a>
                    </li>
                    <h3 class="menu-title">Human Resource</h3><!-- /.menu-title -->
                    <li>
                        <a href="employees.php"> <i class="menu-icon fa fa-users"></i>List of Employees </a>
                    </li>
                    <li>
                        <a href="vacations.php"> <i class="menu-icon fa fa-plane"></i>Vacations </a>
                    </li>
                    <li>
                        <a href="announcement.php"> <i class="menu-icon fa fa-volume-up"></i>Announcement </a>
                    </li>
                    <li>
                        <a href="payroll.php"> <i class="menu-icon fa fa-credit-card"></i>Payroll </a>
                    </li>
                    <h3 class="menu-title">Reports</h3><!-- /.menu-title -->
                    <li>
                        <a href="cases_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Cases Reports </a>
                    </li>
                    <li>
                        <a href="Payments_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Payments Reports </a>
                    </li>
                    <li>
                        <a href="expenses_reports.php"> <i class="menu-icon fa fa-bar-chart-o"></i>Expenses Reports </a>
                    </li>
                    <h3 class="menu-title">Marketing</h3><!-- /.menu-title -->
                    <li>
                        <a href="queries.php"> <i class="menu-icon fa fa-question"></i>Queries </a>
                    </li>
                    <li>
                        <a href="meeting.php"> <i class="menu-icon fa fa-calendar"></i>Meetings </a>
                    </li>
                    <h3 class="menu-title">Administration</h3><!-- /.menu-title -->
                    <li>
                        <a href="users.php"> <i class="menu-icon fa fa-user"></i>Users </a>
                    </li>
                    <li>
                        <a href="system.php"> <i class="menu-icon fa fa-cogs"></i>System </a>
                    </li>
                    <li>
                        <a href="logout.php"> <i class="menu-icon fa fa-sign-out"></i>Logout </a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">
            <div class="header-menu">
                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <h4>Welcome to your dashboard <?= htmlspecialchars($username) ?></h4>
                    </div>
        </header><!-- /header -->
        <!-- Header-->
        <div class="content mt-3">
            <div class="col-sm-12">
                <div class="total-amounts">
                    <h2>Total Paid Amounts per Date</h2>
                    <canvas id="totalAmountsChart" width="400" height="200"></canvas>
                </div>

                <div class="search-form">
                    <h2>Search Payments</h2>
                    <form id="searchForm">
                        <label for="case_id">Case ID:</label>
                        <input type="text" id="case_id" name="case_id"><br><br>
                        <label for="amount">Amount:</label>
                        <input type="text" id="amount" name="amount"><br><br>
                        <label for="payment_date">Payment Date:</label>
                        <input type="date" id="payment_date" name="payment_date"><br><br>
                        <button type="button" onclick="searchPayments()">Search</button>
                    </form>
                </div>

                <div class="search-results">
                    <h2>Search Results</h2>
                    <table id="resultsTable">
                        <thead>
                            <tr>
                                <th>Pay No</th>
                                <th>Case ID</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Remaining</th>
                                <th>Method</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <button type="button" class="btn btn-warning" onclick="showNewPaymentModal()">New Payment</button>
            </div>

            <!-- Modal for New Payment -->
            <div class="modal fade" id="newPaymentModal" tabindex="-1" role="dialog" aria-labelledby="newPaymentModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form action="../system/payments/add_payment.php" method="post">
                            <div class="modal-header">
                                <h5 class="modal-title" id="newPaymentModalLabel">New Payment</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="case_id">Case ID</label>
                                    <select name="case_id" id="case_id" class="form-control">
                                        <?php foreach ($cases as $case): ?>
                                            <option value="<?= $case['id'] ?>">CN<?= $case['id'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="payment_method_id">Payment Method</label>
                                    <select name="payment_method_id" id="payment_method_id" class="form-control">
                                        <?php foreach ($paymentMethods as $method): ?>
                                            <option value="<?= $method['id'] ?>"><?= htmlspecialchars($method['method_name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="amount">Amount</label>
                                    <input type="number" name="amount" id="amount" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="payment_date">Payment Date</label>
                                    <input type="datetime-local" name="payment_date" id="payment_date" class="form-control">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <script>
                // Draw bar chart
                document.addEventListener('DOMContentLoaded', function () {
                    const ctx = document.getElementById('totalAmountsChart').getContext('2d');
                    const dates = <?php echo json_encode(array_column($totalAmounts, 'payment_date')); ?>;
                    const amounts = <?php echo json_encode(array_column($totalAmounts, 'total_amount')); ?>;
                    const data = {
                        labels: dates,
                        datasets: [{
                            label: 'Total Amount',
                            data: amounts,
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        }]
                    };

                    const totalAmountsChart = new Chart(ctx, {
                        type: 'bar',
                        data: data,
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                });

                function searchPayments() {
                    const caseId = document.getElementById('case_id').value;
                    const amount = document.getElementById('amount').value;
                    const paymentDate = document.getElementById('payment_date').value;

                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', '../system/payments/search_payments.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.onreadystatechange = function() {
                        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                            document.querySelector('#resultsTable tbody').innerHTML = this.responseText;
                        }
                    }
                    xhr.send(`case_id=${caseId}&amount=${amount}&payment_date=${paymentDate}`);
                }

                function showNewPaymentModal() {
                    $('#newPaymentModal').modal('show');
                }
            </script>

            <script src="../assets/js/script_cases.js"></script>
            <script src="../vendors/jquery/dist/jquery.min.js"></script>
            <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
            <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
            <script src="../assets/js/main.js"></script>
            <script src="../vendors/chart.js/dist/Chart.bundle.min.js"></script>
            <script src="../assets/js/dashboard.js"></script>
            <script src="../assets/js/widgets.js"></script>
            <script src="../vendors/jqvmap/dist/jquery.vmap.min.js"></script>
            <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
            <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
        </div>
    </div>
</body>
</html>
