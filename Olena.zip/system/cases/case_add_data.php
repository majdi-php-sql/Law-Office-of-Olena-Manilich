<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../../config/db_connect.php';

$caseCategory = $_POST['case_category_name'];
$caseSubcategory = $_POST['case_subcategory_name'];
$caseType = $_POST['case_type_name'];
$caseCourtName = $_POST['case_court_name'];
$caseCourtType = $_POST['case_court_type'];
$client_id = $_POST['client_id'];
$caseShortDescription = $_POST['case_short_description'];
$caseFullDescription = $_POST['case_full_description'];
$caseFees = $_POST['case_fees'];

$uploadedFiles = [];
$targetDir = '../uploads/';
foreach ($_FILES['case_files']['name'] as $key => $name) {
    $targetFile = $targetDir . basename($name);
    if (move_uploaded_file($_FILES['case_files']['tmp_name'][$key], $targetFile)) {
        $uploadedFiles[] = $targetFile;
    }
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('INSERT INTO cases (category_id, subcategory_id, type_id, court_name, court_type, client_id, short_description, full_description, case_fees) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $caseCategory,
        $caseSubcategory,
        $caseType,
        $caseCourtName,
        $caseCourtType,
		$client_id,
        $caseShortDescription,
        $caseFullDescription,
        $caseFees
    ]);

    $caseId = $pdo->lastInsertId();

    foreach ($uploadedFiles as $filePath) {
        $stmt = $pdo->prepare('INSERT INTO case_files (case_id, file_path) VALUES (?, ?)');
        $stmt->execute([$caseId, $filePath]);
    }

    $pdo->commit();
    
    header('Location: ../../superadmin/cases.php');
} catch (Exception $e) {
    $pdo->rollBack();
    echo 'Failed to save the case: ' . $e->getMessage();
}
?>
