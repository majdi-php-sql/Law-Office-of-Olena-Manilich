<?php
// Author: Majdi M. S. Awad
// Client: Olena Manilich
// Date: May 2024
// Email: majdiawad336@gmail.com

require '../../config/db_connect.php';

// Fetch and sanitize input data
$c_id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
$caseCategory = filter_input(INPUT_POST, 'case_category_name', FILTER_SANITIZE_STRING);
$caseSubcategory = filter_input(INPUT_POST, 'case_subcategory_name', FILTER_SANITIZE_STRING);
$caseType = filter_input(INPUT_POST, 'case_type_name', FILTER_SANITIZE_STRING);
$caseCourtName = filter_input(INPUT_POST, 'case_court_name', FILTER_SANITIZE_STRING);
$caseCourtType = filter_input(INPUT_POST, 'case_court_type', FILTER_SANITIZE_STRING);
$client_id = filter_input(INPUT_POST, 'client_id', FILTER_SANITIZE_NUMBER_INT);
$caseShortDescription = filter_input(INPUT_POST, 'case_short_description', FILTER_SANITIZE_STRING);
$caseFullDescription = filter_input(INPUT_POST, 'case_full_description', FILTER_SANITIZE_STRING);
$caseFees = filter_input(INPUT_POST, 'case_fees', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

// Validate that $c_id is set and is an integer
if (!$c_id) {
    die('Invalid case ID');
}

$uploadedFiles = [];
$targetDir = '../uploads/';

foreach ($_FILES['case_files']['name'] as $key => $name) {
    $targetFile = $targetDir . basename($name);
    if (move_uploaded_file($_FILES['case_files']['tmp_name'][$key], $targetFile)) {
        $uploadedFiles[] = $targetFile;
    } else {
        echo 'Failed to upload file: ' . htmlspecialchars($name);
        exit;
    }
}

try {
    $pdo->beginTransaction();

    // Update the case details in the cases table
    $stmt = $pdo->prepare('UPDATE cases SET category_id = ?, subcategory_id = ?, type_id = ?, court_name = ?, court_type = ?, client_id = ?, short_description = ?, full_description = ?, case_fees = ? WHERE id = ?');
    $stmt->execute([
        $caseCategory,
        $caseSubcategory,
        $caseType,
        $caseCourtName,
        $caseCourtType,
        $client_id,
        $caseShortDescription,
        $caseFullDescription,
        $caseFees,
        $c_id
    ]);

    // Insert new files into the case_files table
    $stmt = $pdo->prepare('INSERT INTO case_files (case_id, file_path) VALUES (?, ?)');
    foreach ($uploadedFiles as $filePath) {
        $stmt->execute([$c_id, $filePath]);
    }

    $pdo->commit();

    header('Location: ../../superadmin/cases.php');
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    echo 'Failed to update the case: ' . htmlspecialchars($e->getMessage());
}
?>
