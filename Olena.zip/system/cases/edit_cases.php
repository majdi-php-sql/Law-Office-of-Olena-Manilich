<?php
// Author: Majdi M. S. Awad
// Client: Olena Manilich
// Date: May 2024
// Email: majdiawad336@gmail.com

// Database connection parameters
$host = 'localhost';
$dbname = 'olena';
$user = 'root';
$password = 'Majdi@00800';

try {
    // Set the PDO error mode to exception and create a new PDO instance
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    $pdo = new PDO($dsn, $user, $password, $options);

} catch (PDOException $e) {
    // Catch any errors and display a generic message
    // Log the detailed error message for debugging
    error_log("Database connection error: " . $e->getMessage());
    echo "Database connection failed.";
}
/**
 * To echo each column, use the following variables:
 * - $case['category_name'] to echo the category name
 * - $case['subcategory_name'] to echo the subcategory name
 * - $case['type_name'] to echo the type name
 * - $case['court_name'] to echo the court name
 * - $case['court_type'] to echo the court type
 * - $case['client_name'] to echo the client name
 * - $case['short_description'] to echo the short description
 * - $case['full_description'] to echo the full description
 * - $case['case_fees'] to echo the case fees
 */
$c_id = $_GET['id'];

$query = "
    SELECT 
        cases.id,
        cases.court_name,
        cases.court_type,
        cases.short_description,
        cases.full_description,
        cases.case_fees,
        case_categories.name AS category_name,
        case_subcategories.name AS subcategory_name,
        case_types.name AS type_name,
        clients.name AS client_name,
		cases.category_id,
		cases.subcategory_id,
		cases.type_id,
		cases.client_id
    FROM 
        cases
    LEFT JOIN 
        case_categories ON cases.category_id = case_categories.id
    LEFT JOIN 
        case_subcategories ON cases.subcategory_id = case_subcategories.id
    LEFT JOIN 
        case_types ON cases.type_id = case_types.id
    LEFT JOIN 
        clients ON cases.client_id = clients.id
    WHERE
        cases.id = :c_id
";

$stmt = $pdo->prepare($query);
$stmt->execute(['c_id' => $c_id]);

if ($stmt->rowCount() > 0) {
    $cases = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($cases as $case) {

    }
} else {
    echo "No cases found.";
}

$pdo = null;
?>
