<?php
// Author: Majdi M. S. Awad
// Client: Olena Manilich
// Date: May 2024
// Email: majdiawad336@gmail.com

$cf_id = $_GET['id'];

require '../config/db_connect.php';

$sql = "SELECT * FROM case_files WHERE case_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$cf_id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $file_path = $result['file_path'];
    $upload_date = $result['upload_date'];
} else {
    echo "No case files found with the provided case ID.";
}

$stmt = null;
$pdo = null;
?>
