<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../../config/db_connect.php';

$category = $_GET['category'];

$stmt = $pdo->prepare('SELECT id, name FROM case_subcategories WHERE category_id = ?');
$stmt->execute([$category]);
$subcategories = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($subcategories);

?>
