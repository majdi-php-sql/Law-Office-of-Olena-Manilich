<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../../config/db_connect.php';

$stmt = $pdo->query('SELECT id, name FROM case_types');
$types = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($types);
?>
