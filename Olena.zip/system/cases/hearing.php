<?php
// Connect to the database
require '../../config/db_connect.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data
    $case_id = filter_input(INPUT_POST, 'case_id', FILTER_SANITIZE_NUMBER_INT);
    $court_date = filter_input(INPUT_POST, 'court_date', FILTER_SANITIZE_STRING);

    // Check if the required fields are not empty
    if (!empty($case_id) && !empty($court_date)) {
        try {
            // Prepare an insert statement
            $sql = "INSERT INTO court_dates (case_id, court_date) VALUES (:case_id, :court_date)";
            $stmt = $pdo->prepare($sql);

            // Bind parameters
            $stmt->bindParam(':case_id', $case_id, PDO::PARAM_INT);
            $stmt->bindParam(':court_date', $court_date, PDO::PARAM_STR);

            // Execute the statement
            if ($stmt->execute()) {
                // Redirect to the case details page with a success message
                header("Location: ../../superadmin/edit_case.php?id=" . $case_id . "&message=Hearing added successfully");
                exit();
            } else {
                // Redirect to the case details page with an error message
                header("Location: ../../superadmin/edit_case.php?id=" . $case_id . "&error=Failed to add hearing");
                exit();
            }
        } catch (PDOException $e) {
            // Redirect to the case details page with an error message
            header("Location: ../../superadmin/edit_case.php?id=" . $case_id . "&error=Database error: " . $e->getMessage());
            exit();
        }
    } else {
        // Redirect to the case details page with an error message
        header("Location: ../../superadmin/edit_case.php?id=" . $case_id . "&error=Please fill in all required fields");
        exit();
    }
} else {
    // Redirect to the cases page if the form was not submitted
    header("Location: ../../superadmin/edit_case.php");
    exit();
}

// Close the database connection
$pdo = null;
?>
