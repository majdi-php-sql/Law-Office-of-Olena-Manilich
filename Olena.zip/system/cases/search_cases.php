<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

// Database connection parameters
$host = 'localhost';
$dbname = 'olena';
$user = 'root';
$password = 'Majdi@00800';

try {
    // Set the PDO error mode to exception and create a new PDO instance
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    $pdo = new PDO($dsn, $user, $password, $options);

} catch (PDOException $e) {
    // Catch any errors and display a generic message
    // Log the detailed error message for debugging
    error_log("Database connection error: " . $e->getMessage());
    echo "Database connection failed.";
}


$limit = isset($_POST['limit']) ? intval($_POST['limit']) : 10;
$offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;

$whereClauses = [];
$params = [];

if (isset($_POST['id']) && $_POST['id'] !== '') {
    $whereClauses[] = 'cases.id = :id';
    $params[':id'] = $_POST['id'];
}
if (isset($_POST['category_id']) && $_POST['category_id'] !== '') {
    $whereClauses[] = 'cases.category_id = :category_id';
    $params[':category_id'] = $_POST['category_id'];
}
if (isset($_POST['subcategory_id']) && $_POST['subcategory_id'] !== '') {
    $whereClauses[] = 'cases.subcategory_id = :subcategory_id';
    $params[':subcategory_id'] = $_POST['subcategory_id'];
}
if (isset($_POST['type_id']) && $_POST['type_id'] !== '') {
    $whereClauses[] = 'cases.type_id = :type_id';
    $params[':type_id'] = $_POST['type_id'];
}
if (isset($_POST['client_id']) && $_POST['client_id'] !== '') {
    $whereClauses[] = 'cases.client_id = :client_id';
    $params[':client_id'] = $_POST['client_id'];
}
if (isset($_POST['court_name']) && $_POST['court_name'] !== '') {
    $whereClauses[] = 'cases.court_name = :court_name';
    $params[':court_name'] = $_POST['court_name'];
}
if (isset($_POST['court_type']) && $_POST['court_type'] !== '') {
    $whereClauses[] = 'cases.court_type = :court_type';
    $params[':court_type'] = $_POST['court_type'];
}

$whereSql = '';
if (!empty($whereClauses)) {
    $whereSql = 'WHERE ' . implode(' AND ', $whereClauses);
}

$sql = "SELECT 
            cases.id,
            case_categories.name as category_name,
            case_subcategories.name as subcategory_name,
            case_types.name as type_name,
            cases.court_name,
            cases.court_type,
            clients.name as client_name
        FROM cases
        JOIN case_categories ON cases.category_id = case_categories.id
        JOIN case_subcategories ON cases.subcategory_id = case_subcategories.id
        JOIN case_types ON cases.type_id = case_types.id
        JOIN clients ON cases.client_id = clients.id
        $whereSql
        LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $key => &$val) {
    $stmt->bindParam($key, $val);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($result);
?>
