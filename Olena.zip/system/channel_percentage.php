<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

try {
    $totalQueries = 0;
    $channelCounts = [
        'Facebook' => 0,
        'Twitter' => 0,
        'Linkedin' => 0,
        'Google' => 0
    ];

    $stmtTotal = $pdo->prepare("SELECT COUNT(*) AS total_queries FROM queries");
    $stmtTotal->execute();
    
    $resultTotal = $stmtTotal->fetch(PDO::FETCH_ASSOC);
    if ($resultTotal) {
        $totalQueries = $resultTotal['total_queries'];
    }

    $stmtChannels = $pdo->prepare("SELECT channel, COUNT(*) AS count FROM queries WHERE channel IN ('Facebook', 'Twitter', 'Linkedin', 'Google') GROUP BY channel");
    $stmtChannels->execute();
    
    $resultsChannels = $stmtChannels->fetchAll(PDO::FETCH_ASSOC);
    foreach ($resultsChannels as $row) {
        $channelCounts[$row['channel']] = $row['count'];
    }

    foreach ($channelCounts as $channel => $count) {
        $percentage = $totalQueries ? ($count / $totalQueries) * 100 : 0;
    }

    $facebookPercentage = $totalQueries ? ($channelCounts['Facebook'] / $totalQueries) * 100 : 0;
    $twitterPercentage = $totalQueries ? ($channelCounts['Twitter'] / $totalQueries) * 100 : 0;
    $linkedinPercentage = $totalQueries ? ($channelCounts['Linkedin'] / $totalQueries) * 100 : 0;
    $googlePercentage = $totalQueries ? ($channelCounts['Google'] / $totalQueries) * 100 : 0;

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
