<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

$totalExpenses = 0;

try {
    $stmt = $pdo->prepare("SELECT SUM(amount) AS total FROM expenses");
    $stmt->execute();
    
    $result_e = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result_e) {
        $totalExpenses = $result_e['total'];
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
