<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

try {
    $totalMeetings = 0;

    $stmtCount = $pdo->prepare("SELECT COUNT(*) AS total_meetings FROM meetings");
    $stmtCount->execute();
    
    $resultCount = $stmtCount->fetch(PDO::FETCH_ASSOC);
    if ($resultCount) {
        $totalMeetings = $resultCount['total_meetings'];
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
