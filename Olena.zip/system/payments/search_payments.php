<?php
// Include the session and database connection files
require '../../config/session.php';
require '../../config/db_connect.php';

$caseId = $_POST['case_id'] ?? '';
$amount = $_POST['amount'] ?? '';
$paymentDate = $_POST['payment_date'] ?? '';

// Build the query
$query = "SELECT p.id, p.case_id, p.amount, p.payment_date, p.payment_method_id, c.case_fees, m.method_name
          FROM payments p
          JOIN cases c ON p.case_id = c.id
          JOIN payment_methods m ON p.payment_method_id = m.id
          WHERE 1=1";

$params = [];
if ($caseId !== '') {
    $query .= " AND p.case_id = :case_id";
    $params[':case_id'] = $caseId;
}
if ($amount !== '') {
    $query .= " AND p.amount = :amount";
    $params[':amount'] = $amount;
}
if ($paymentDate !== '') {
    $query .= " AND DATE(p.payment_date) = :payment_date";
    $params[':payment_date'] = $paymentDate;
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate remaining for each payment
foreach ($results as $key => $result) {
    $remainingQuery = $pdo->prepare("SELECT SUM(amount) AS total_paid FROM payments WHERE case_id = :case_id AND payment_date <= :payment_date");
    $remainingQuery->execute([':case_id' => $result['case_id'], ':payment_date' => $result['payment_date']]);
    $totalPaid = $remainingQuery->fetch(PDO::FETCH_ASSOC)['total_paid'];
    $remaining = $result['case_fees'] - $totalPaid;
    $results[$key]['remaining'] = $remaining;
}

// Print the results
foreach ($results as $row) {
    echo "<tr>
            <td>Pay No: {$row['id']}</td>
            <td>CN{$row['case_id']}</td>
            <td>\${$row['amount']}</td>
            <td>{$row['payment_date']}</td>
            <td>\${$row['remaining']}</td>
            <td>{$row['method_name']}</td>
          </tr>";
}
?>
