<?php
// Auther: Majdi M. S. Awad
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

$totalPayments = 0;

try {
    $stmt = $pdo->prepare("SELECT SUM(amount) AS total FROM payments");
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $totalPayments = $result['total'];
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
