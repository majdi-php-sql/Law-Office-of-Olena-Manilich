<?php
// Auther: Majdi M. S. Awad 
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

try {
    $totalCases = 0;
    $totalCaseFees = 0.0;

    $stmtCount = $pdo->prepare("SELECT COUNT(*) AS total_cases FROM cases");
    $stmtCount->execute();
    
    $resultCount = $stmtCount->fetch(PDO::FETCH_ASSOC);
    if ($resultCount) {
        $totalCases = $resultCount['total_cases'];
    }

    $stmtFees = $pdo->prepare("SELECT SUM(case_fees) AS total_fees FROM cases");
    $stmtFees->execute();
    
    $resultFees = $stmtFees->fetch(PDO::FETCH_ASSOC);
    if ($resultFees) {
        $totalCaseFees = $resultFees['total_fees'];
    }

} catch (PDOException $e) {

    echo "Error: " . $e->getMessage();
}
?>
