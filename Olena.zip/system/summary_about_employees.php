<?php
// Auther: Majdi M. S. Awad 
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

try {
    $totalEmployees = 0;
    $uniquePositions = 0;

    $stmtCount = $pdo->prepare("SELECT COUNT(*) AS total_employees FROM employees");
    $stmtCount->execute();
    
    $resultCount = $stmtCount->fetch(PDO::FETCH_ASSOC);
    if ($resultCount) {
        $totalEmployees = $resultCount['total_employees'];
    }

    $stmtPositions = $pdo->prepare("SELECT COUNT(DISTINCT position) AS unique_positions FROM employees");
    $stmtPositions->execute();
    
    $resultPositions = $stmtPositions->fetch(PDO::FETCH_ASSOC);
    if ($resultPositions) {
        $uniquePositions = $resultPositions['unique_positions'];
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
