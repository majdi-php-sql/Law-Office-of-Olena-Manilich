<?php
// Auther: Majdi M. S. Awad 
// Client: Olena Manilich
// date: May 2024
// email: majdiawad336@gmail.com

require '../config/db_connect.php';

try {
    $totalQueries = 0;
    $mostDuplicatedChannel = "";

    $stmtCount = $pdo->prepare("SELECT COUNT(*) AS total_queries FROM queries");
    $stmtCount->execute();
    
    $resultCount = $stmtCount->fetch(PDO::FETCH_ASSOC);
    if ($resultCount) {
        $totalQueries = $resultCount['total_queries'];
    }

    $stmtChannel = $pdo->prepare("SELECT channel, COUNT(channel) AS channel_count FROM queries GROUP BY channel ORDER BY channel_count DESC LIMIT 1");
    $stmtChannel->execute();
    
    $resultChannel = $stmtChannel->fetch(PDO::FETCH_ASSOC);
    if ($resultChannel) {
        $mostDuplicatedChannel = $resultChannel['channel'];
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
