<?php
// Include the session and database connection files
require '../config/session.php';
require '../config/db_connect.php';

// Fetch total paid amounts per date
$totalAmountsQuery = $pdo->prepare("SELECT DATE(payment_date) as payment_date, SUM(amount) as total_amount FROM payments GROUP BY DATE(payment_date)");
$totalAmountsQuery->execute();
$totalAmounts = $totalAmountsQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .total-amounts p {
            margin: 5px 0;
        }
        .search-form {
            margin-top: 20px;
        }
        .search-results {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h1>Payments</h1>
    <div class="total-amounts">
        <h2>Total Paid Amounts per Date</h2>
        <canvas id="totalAmountsChart" width="400" height="200"></canvas>
    </div>

    <div class="search-form">
        <h2>Search Payments</h2>
        <form id="searchForm">
            <label for="case_id">Case ID:</label>
            <input type="text" id="case_id" name="case_id"><br><br>
            <label for="amount">Amount:</label>
            <input type="text" id="amount" name="amount"><br><br>
            <label for="payment_date">Payment Date:</label>
            <input type="date" id="payment_date" name="payment_date"><br><br>
            <button type="button" onclick="searchPayments()">Search</button>
        </form>
    </div>

    <div class="search-results">
        <h2>Search Results</h2>
        <table id="resultsTable">
            <thead>
                <tr>
                    <th>Pay No</th>
                    <th>Case ID</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Remaining</th>
                    <th>Method</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

    <script>
        // Draw bar chart
        document.addEventListener('DOMContentLoaded', function () {
            const ctx = document.getElementById('totalAmountsChart').getContext('2d');
            const data = {
                labels: <?php echo json_encode(array_column($totalAmounts, 'payment_date')); ?>,
                datasets: [{
                    label: 'Total Amount',
                    data: <?php echo json_encode(array_column($totalAmounts, 'total_amount')); ?>,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            };

            const totalAmountsChart = new Chart(ctx, {
                type: 'bar',
                data: data,
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });

        function searchPayments() {
            const caseId = document.getElementById('case_id').value;
            const amount = document.getElementById('amount').value;
            const paymentDate = document.getElementById('payment_date').value;

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'search_payments.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                    document.querySelector('#resultsTable tbody').innerHTML = this.responseText;
                }
            }
            xhr.send(`case_id=${caseId}&amount=${amount}&payment_date=${paymentDate}`);
        }
    </script>
</body>
</html>
